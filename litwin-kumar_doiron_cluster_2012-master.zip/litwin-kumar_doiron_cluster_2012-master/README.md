# litwin-kumar_doiron_cluster_2012
Code for generating balanced network activity from this paper:
Litwin-Kumar, Ashok, and Brent Doiron. "Slow dynamics and high variability in balanced cortical networks with clustered connections." Nature neuroscience 15.11 (2012): 1498-1505.

Also, see http://www.columbia.edu/~ak3625/index.shtml#code.
